package com.lmax.api.order;

import com.lmax.api.account.AccountSubscriptionRequest;

/**
 * Request to subscribe to Execution events.
 */
public class ExecutionSubscriptionRequest extends AccountSubscriptionRequest
{
}
